<?php

require_once 'core.php';
require_once 'views/html.php';