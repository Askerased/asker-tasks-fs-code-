<?php

$sinif = [
	[
		'ad'   => 'Nermin Eliyeva',
		'yash' => 12,
		'cins' => 'q'
	],
	[
		'ad'   => 'Kamil Rahimli',
		'yash' => 13,
		'cins' => 'k'
	],
	[
		'ad'   => 'Zaur Qurbaneliyev',
		'yash' => 12,
		'cins' => 'k'
	],
	[
		'ad'   => 'Melahet Iskenderli',
		'yash' => 12,
		'cins' => 'q'
	],
	[
		'ad'   => 'Ali Rzayev',
		'yash' => 11,
		'cins' => 'k'
	],
	[
		'ad'   => 'Ramin Orucov',
		'yash' => 10,
		'cins' => 'k'
	],
	[
		'ad'   => 'Ayxan Memmedov',
		'yash' => 13,
		'cins' => 'k'
	],
	[
		'ad'   => 'Zamiq Aliyev',
		'yash' => 14,
		'cins' => 'k'
	],
	[
		'ad'   => 'Esmaye Mustafayeva',
		'yash' => 12,
		'cins' => 'q'
	],
	[
		'ad'   => 'Veli Kerimli',
		'yash' => 15,
		'cins' => 'k'
	]
];