<?php

require_once 'data.php';
require_once 'core.php';

print_r( statistics( $sinif ) );